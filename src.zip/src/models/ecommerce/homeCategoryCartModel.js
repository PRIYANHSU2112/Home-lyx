const mongoose = require("mongoose");
let objectId = mongoose.Types.ObjectId;

const eCommerceHomeCatergoryCartModel = mongoose.Schema(
  {
    title: String,
    subtitle: String,
    image: String,
    backgroundColourCode: String,
    taskColourCode: String,
    pCategory: { type: objectId, ref: "eCommerceCategoryModel"},
    category: { type: objectId, ref: "eCommerceCategoryModel"},
    slug:{
      type:String
    }
  },
  { timestamps: true }
);

module.exports = mongoose.model(
  "E-CommerceHomeCatergoryCartModel",
  eCommerceHomeCatergoryCartModel
);
