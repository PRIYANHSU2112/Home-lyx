const mongoose = require("mongoose");

const ecommerceAppBannerModel = new mongoose.Schema(
  {
    banner: String,
  },
  { timestamps: true }
);
module.exports = mongoose.model(
  "e-commerceAppBannerModel",
  ecommerceAppBannerModel
);
