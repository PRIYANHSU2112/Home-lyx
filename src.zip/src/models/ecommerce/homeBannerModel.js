const mongoose = require("mongoose");

const eCommerceHomeBannerModel = new mongoose.Schema(
  {
    title: String,
    banner: String,
    disable:{
      type:Boolean,
      default:false
    }
  },
  { timestamps: true }
);
module.exports = mongoose.model("E-CommerceHomeBannerModel", eCommerceHomeBannerModel);
