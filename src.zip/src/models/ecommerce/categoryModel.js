const mongoose = require("mongoose");
let objectId = mongoose.Types.ObjectId;
const ecommerceCategoryModel = new mongoose.Schema(
  {
    name: String,
    icon: {
      type: String,
      default: "/public/images/Default-Img.jpg",
    },
    banner: [
      {
        type: { type: String, enum: ["IMAGE", "VIDEO"], default: "IMAGE" },
        url: { type: String, default: "/public/images/Default-Img.jpg" },
      },
    ],
    pCategory: { type: objectId, ref: "eCommerceCategoryModel", default: null },
    disable: { type: Boolean, default: false },

    slug: {
      type: String,
    },
  },
  { timestamps: true },
);

module.exports = mongoose.model(
  "eCommerceCategoryModel",
  ecommerceCategoryModel,
);
