const mongoose = require("mongoose");

const ecommerceBrandModel = new mongoose.Schema(
  {
    name: String,
    image: String,
    disable: { type: Boolean, default: false },
    categoryId: { type: mongoose.Types.ObjectId, ref: "eCommerceCategoryModel" },
  },
  { timestamps: true }
);
module.exports = mongoose.model("eCommerceBrandModel", ecommerceBrandModel);
